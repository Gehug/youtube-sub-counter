# ESP32-SUB-COUNTER
A simple YouTube and Instagram Subscriber Counter

This is an ongoing project to create a subscriber counter using an ESP32 Dev module with a LED Matrix Display. 

Follow the instructions below to create your own.

Use the code on your project. 

- Enter the Wifi SSID and your password at the marked location in the file. 
- Enter your Google API V3 key at the marked location
- Enter your Channel ID at the marked location
- Make sure you install the right library's
    - MD_Parola
    - MD_MAX72xx
    - JsonStreamingParser
    - InstagramStats
    - YoutubeApi
    - and the gilST.h will be in the folder.

That's it. 

I recommend watch the video from "The Swedish Maker" more details or read the complete guide over on https://theswedishmaker.com/2020/05/10/making-a-20-subscriber-counter/
